<footer>
    &copy; HayGirl 2019
</footer>
<?php /**PATH /home/vagrant/code/HayGirl/resources/views/layout/_footer.blade.php ENDPATH**/ ?>