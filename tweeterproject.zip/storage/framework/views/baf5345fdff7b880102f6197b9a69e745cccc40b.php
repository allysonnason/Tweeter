<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-3 p-5">
            <img src="https://scontent.fyyc3-1.fna.fbcdn.net/v/t1.0-9/67389382_2801256249902842_3431914899431751680_n.jpg?_nc_cat=101&_nc_oc=AQkrTHpcL3T93m34JC48RhSBjOq6ejciH3J_9nT3sV4s31pxiVXkihgigfBPHf3DGPY&_nc_ht=scontent.fyyc3-1.fna&oh=ad7436c998b626d1468367cb39d1bae0&oe=5DB5962B" alt ="haygirl logo" class="rounded-circle"/>
        </div>
        <div class="col-9 pt-5">

                <div class="d-flex">
                    <div><strong>22</strong> posts </div>
                    <div><strong>115</strong> followers </div>
                    <div><strong>212</strong> following </div>
                </div>
                <a href="#">Add New Post</a>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/HayGirl/resources/views//home.blade.php ENDPATH**/ ?>