

<div class="container">
    <div class="card">
        <div class="card-body">
            <h5 class="card-header"><a href ="/profiles/<?php echo e($post->user->id); ?>"><?php echo e($post->user->name); ?></a></h5>

            <p class="card-text"><?php echo e($post->body); ?></p>
        </div>

        
            <?php if(Auth::check()): ?>
            <form action="<?php echo e(route('comments.store', $post->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <p><?php echo e(Form::textarea('body', old('body'))); ?></p>
                <?php echo e(Form::hidden('post_id', $post->id)); ?>

                <p><?php echo e(Form::submit('Post')); ?></p>
            </form>
            <?php endif; ?>

            <?php $__empty_1 = true; $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <p><?php echo e($comment->user->name); ?></p>
                <p><?php echo e($comment->body); ?></p>
                <hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>This post has no comments</p>
            <?php endif; ?>

        <a href="/posts/<?php echo e($post->id); ?>/like" class="btn btn-primary">Like</a>
        (<?php echo e($post->likes()->count()); ?>)

        <?php if(Auth::id() == $post->user_id): ?>
        <form action="/posts/<?php echo e($post->id); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo e(method_field('DELETE')); ?>

            <button type="submit" class="btn btn-dark">Delete</button>
            <a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-dark">Edit</a>
        </form>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH /home/vagrant/code/HayGirl/resources/views/posts/_post.blade.php ENDPATH**/ ?>