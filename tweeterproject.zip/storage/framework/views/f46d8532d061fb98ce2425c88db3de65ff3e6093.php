<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify content-center">
        <div class="col-sm-6">
            <div class="profile-info">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title"><?php echo e($user->name); ?></h3>
                    <p class="card-text">

                        <?php echo e($profile->interests); ?> <br />
                        <?php echo e($profile->location); ?> <br />
                        <?php echo e($profile->horsename); ?> <br />
                        <?php echo e($profile->breed); ?> <br /></p>

                        <?php if(Auth::id()== $user->profile->user_id): ?>
                        <a href ="/profiles/<?php echo e($user->id); ?>/edit" class="btn btn-secondary">Edit Profile</a><br />
                        <?php endif; ?>
                    </div>
                </div>
                </div><br />


                <div class="card">

                        <div class="card-body ">
                            <?php $__currentLoopData = $user->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('posts._post', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div><br />
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/HayGirl/resources/views/profiles/show.blade.php ENDPATH**/ ?>