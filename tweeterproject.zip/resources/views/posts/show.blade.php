@extends('layout/main')
@section('content')
@include('posts._post')
@endsection
